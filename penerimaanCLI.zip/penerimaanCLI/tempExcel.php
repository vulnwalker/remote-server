<?php
include 'config.php';
include 'excel_reader.php';
class getIdPenerimaan extends Config{
  var $a1 = '12';
  var $a = '10';
  var $b = '14';
  var $VERSI_NAME = 'BOGOR';
  var $FIELD_KODE_BELANJA_MODAL = "CONCAT(k, '.', l, '.', m) ";
  var $KODE_BELANJA_MODAL = '5.2.3';
  function __construct(){
      $tbl_rek = "t_penerimaan_rekening";
      $options = getopt(null, ["limitData:"]);
      $optionsTemp = getopt(null, ["tempName:"]);
      $limitData = $options['limitData'];
      $tempName = $optionsTemp['tempName'];
      $namaFile ='migrasi2.xls';
      $nameFileExcel = $namaFile;
      $excel = new PhpExcelReader;
      $excel->read("$namaFile");
      $sheet = $excel->sheets[0];
         $x = 2;
         $jumlahData = $sheet['numRows'] - 1;
         while($x <= $sheet['numRows']) {
           $arrayDetailPenerimaan = array();
           $idPenerimaan = $sheet['cells'][$x][1];
           $getDataDetailPenerimaan = $this->sqlQuery("select * from t_penerimaan_barang_det where refid_terima = '$idPenerimaan'");
           $dataPenerimaan = $this->sqlArray($this->sqlQuery("select * from t_penerimaan_barang where Id = '$idPenerimaan'"));
           $barangSudahDiProses = 0;
           while ($dataDetailPenerimaan = $this->sqlArray($getDataDetailPenerimaan)) {
             $jumlahBarang = $dataDetailPenerimaan['jml'];
             $hargaPerolehan = $dataDetailPenerimaan['dat_hargabeli1'] + $dataDetailPenerimaan['dat_atribusi2'];
             $asalUsul = $dataPenerimaan['asal_usul'];
             if($asalUsul == '1'){
               $cek_kodeBm = $this->QyrTmpl1Brs($tbl_rek, "COUNT(*) as hitung", "WHERE refid_terima='$idPenerimaan' AND ".$this->FIELD_KODE_BELANJA_MODAL." = '".$this->KODE_BELANJA_MODAL."' AND sttemp='0' ");$cek.=$cek_kodeBm['cek'];
           		$hsl_cek_Bm = $cek_kodeBm['hasil'];
           		$cek_kodeBm2 = $this->QyrTmpl1Brs("t_atribusi_rincian", "COUNT(*) as hitung", "WHERE refid_terima='$idPenerimaan' AND ".$this->FIELD_KODE_BELANJA_MODAL." = '".$this->KODE_BELANJA_MODAL."' AND sttemp='0' ");$cek.=$cek_kodeBm2['cek'];
           		$hsl_cek_Bm2 = $cek_kodeBm2['hasil'];
               if($hsl_cek_Bm['hitung'] < 1 && $hsl_cek_Bm2['hitung'] < 1){
           			$asalUsul = "6";
           		}
             }
             $statusAset = $this->getStatusAset(3,1,$hargaPerolehan,$dataDetailPenerimaan['f'],$dataDetailPenerimaan['g'],$dataDetailPenerimaan['h'],$dataDetailPenerimaan['i'],$dataDetailPenerimaan['j'],$this->getTahun($dataPenerimaan['tgl_dokumen_sumber']));
            $query = "select  sf_penerimaan_posting_$tempName('".$dataDetailPenerimaan['Id']."','".$this->getTahun($dataPenerimaan['tgl_dokumen_sumber'])."','".$statusAset."', '".$this->a."', '".$this->a1."', '".$this->b."','".$asalUsul."','".$dataPenerimaan['tgl_buku']."','".$jumlahBarang."','0','2017','BOT CLI','0000','".$dataPenerimaan['sumber_dana']."') as hasil ";
            $concatBarangSudahDiProses = $this->sqlArray($this->sqlQuery($query));
            $explodeConcatBarangProses = explode(" ",$concatBarangSudahDiProses['hasil']);
            $barangSudahDiProses = $explodeConcatBarangProses[3];
            $jumlahBarangMasuk += $jumlahBarang;
            echo "ID PENERIMAAN => $idPenerimaan | detail => ".$query." ". "Jumlah Data Masuk = $jumlahBarangMasuk " .  $nomorUrutWhile." / ".$sheet['numRows']." ".$concatBarangSudahDiProses['hasil']." \n";
           }
           $nomorUrutWhile = $x - 1;
           $x++;
         }
  }

  function stringDetector($string){
      $string = str_replace("`","",$string);
      $string = str_replace("'","",$string);
      $string = str_replace(" ","",$string);
      return $string;
  }
  function getTahun($tanggal){
    $explodeTanggal = explode("-",$tanggal);
    return $explodeTanggal[0];
  }

  function getStatusAset($fmSTATUSASET, $fmKONDISIBARANG, $fmHARGABARANG, $f,$g,$h,$i,$j,$fmTAHUN=''){
  	switch($this->VERSI_NAME){ //$fmSTATUSASET, $ArBarang[0], $fmHARGABARANG

  		case 'SERANG' : { //kab
  			if($fmSTATUSASET !=5 && $fmSTATUSASET !=6 && $fmSTATUSASET !=7  ){//pindah tangan, tgr, pemitraan, (tidak rubah aset)
  				//if($fmKONDISIBARANG==3 && ($fmSTATUSASET==3 || $fmSTATUSASET==8 || $fmSTATUSASET==9) ){ //rb otomatis
  				if($fmKONDISIBARANG==3 ){ //rb oto
  					$fmSTATUSASET=9;
  				}else{ //extra, intra , tdk oto
  					if(
  						$fmHARGABARANG< 1000000
  					){
  						$fmSTATUSASET = 10;//extra
  					//}else if( $ArBarang[0].$ArBarang[1]=='0724'  ){
  					//	$fmSTATUSASET = 8;	//tak berwujud
  					}else{
  						//$fmSTATUSASET = 3;	//intra
  						$fmSTATUSASET = $f.$g =='0724' ? 8:3;
  					}
  				}
  			}
  			break;
  		}
  		case 'GARUT' : {
  			if($fmSTATUSASET !=5 && $fmSTATUSASET !=6 && $fmSTATUSASET !=7  ){//pindah tangan, tgr, pemitraan, (tidak rubah aset)

  				if($fmKONDISIBARANG==3 ){ //rb oto
  					$fmSTATUSASET=9;
  				}else{
  					if(
  						( $fmHARGABARANG >= 250000  ) ||
  						( $f.$g =='0517'   ) || //buku
  						( $f.$g.$h.$i.$j=='02060201046' ) || //karpet
  						( $f=='01' || $f=='03' || $f=='04' || $f=='06' || $f=='07')
  					){
  						//$fmSTATUSASET = 3;
  						$fmSTATUSASET = $f.$g =='0724' ? 8:3;
  					}else{
  						$fmSTATUSASET = 10;
  					}
  				}
  			}
  			break;
  		}
  		case 'BOGOR' : {
  			if($fmSTATUSASET !=5 && $fmSTATUSASET !=6 && $fmSTATUSASET !=7 && $fmSTATUSASET!=10  ){	//pindah tangan, tgr, pemitraan, (tidak rubah aset)
  				/*if($fmKONDISIBARANG==3  ){ //RB oto aset lainnya
  					$fmSTATUSASET=9;
  				}else{
  					if ( $fmSTATUSASET == '' ){
  						$fmSTATUSASET = $f.$g =='0724' ? 8:3; //ATB
  					}
  				}*/
  				//cek intra
  				if( ($fmHARGABARANG < 100000 && $fmTAHUN<=2014 ) || ( $fmHARGABARANG <300000 && $fmTAHUN>2014 )  ){ //ekstra
  					$fmSTATUSASET=10;
  				}else if($fmKONDISIBARANG==3 ){ //aset lain
  					$fmSTATUSASET=9;
  				}else if( $f.$g =='0724'){
  					$fmSTATUSASET = 8; //ATB
  				}else{
  					$fmSTATUSASET = 3;
  				}
  			}
  			if($f == "05")$fmSTATUSASET = 3;
  			break;
  		}


  	}

  	return $fmSTATUSASET;
  }

  function QyrTmpl1Brs($tablenya, $field='*',$where = '',$eksekusi=1) {
		$qry = "SELECT $field FROM $tablenya $where";
		$hasil =array();
		if($eksekusi == 1){
			$aqry = $this->sqlQuery($qry);
			$hasil = $this->sqlArray($aqry);
		}


		return array('hasil'=>$hasil, 'cek'=>$qry);
	}


}

$wakwaw = new getIdPenerimaan();







 ?>
