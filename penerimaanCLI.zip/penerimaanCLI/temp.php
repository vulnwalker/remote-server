<?php
include 'config.php';
class postingPenerimaan extends Config{
  var $a1 = '28';
  var $a = '12';
  var $b = '01';
  var $VERSI_NAME = 'BOGOR';
  var $FIELD_KODE_BELANJA_MODAL = "CONCAT(k, '.', l, '.', m) ";
  var $KODE_BELANJA_DIPILIH = '5.2';
  function __construct(){
      $options = getopt(null, ["limitData:"]);
      $optionsTemp = getopt(null, ["tempName:"]);
      $limitData = $options['limitData'];
      $tempName = $optionsTemp['tempName'];
      if(!empty($limitData)){
        $limitData = " limit $limitData";
      }
      $jumlahPerimanaan = $this->sqlRowCount($this->sqlQuery("select Id from t_penerimaan_barang where status_validasi = '1' and status_posting = '0' and jns_trans = '1'  $limitData"));
      $getDataPenerimaan = $this->sqlQuery("select * from t_penerimaan_barang where status_validasi = '1' and status_posting = '0' and jns_trans = '1'  $limitData");
      $nomorUrutWhile = 1;
      while ($dataPenerimaan = $this->sqlArray($getDataPenerimaan)) {
        $arrayDetailPenerimaan = array();
        $idPenerimaan = $dataPenerimaan['Id'];
        $getDataDetailPenerimaan = $this->sqlQuery("select * from t_penerimaan_barang_det where refid_terima = '$idPenerimaan'");
        $barangSudahDiProses = 0;
        while ($dataDetailPenerimaan = $this->sqlArray($getDataDetailPenerimaan)) {
          $jumlahBarang = $dataDetailPenerimaan['jml'];
          $hargaPerolehan = $dataDetailPenerimaan['dat_hargabeli1'] + $dataDetailPenerimaan['dat_atribusi2'];
          $asalUsul = $dataPenerimaan['asal_usul'];
          if($asalUsul == '1'){
            $cek_kodeBm = $this->QyrTmpl1Brs($tbl_rek, "COUNT(*) as hitung", "WHERE refid_terima='$Id' AND ".$this->FIELD_KODE_BELANJA_MODAL." = '".$this->KODE_BELANJA_MODAL."' AND sttemp='0' ");$cek.=$cek_kodeBm['cek'];
        		$hsl_cek_Bm = $cek_kodeBm['hasil'];
        		$cek_kodeBm2 = $this->QyrTmpl1Brs("t_atribusi_rincian", "COUNT(*) as hitung", "WHERE refid_terima='$Id' AND ".$this->FIELD_KODE_BELANJA_MODAL." = '".$this->KODE_BELANJA_MODAL."' AND sttemp='0' ");$cek.=$cek_kodeBm2['cek'];
        		$hsl_cek_Bm2 = $cek_kodeBm2['hasil'];
            if($hsl_cek_Bm['hitung'] < 1 && $hsl_cek_Bm2['hitung'] < 1){
        			$asalUsul = "6";
        		}
          }
          $statusAset = $this->getStatusAset(3,1,$hargaPerolehan,$dataDetailPenerimaan['f'],$dataDetailPenerimaan['g'],$dataDetailPenerimaan['h'],$dataDetailPenerimaan['i'],$dataDetailPenerimaan['j'],$this->getTahun($dataPenerimaan['tgl_dokumen_sumber']));
         $query = "select  sf_penerimaan_posting_$tempName('".$dataDetailPenerimaan['Id']."','".$this->getTahun($dataPenerimaan['tgl_dokumen_sumber'])."','".$statusAset."', '".$this->a1."', '".$this->a."', '".$this->b."','".$asalUsul."','".$dataPenerimaan['tgl_buku']."','".$jumlahBarang."','0','2017','BOT CLI','0000','".$dataPenerimaan['sumber_dana']."') as hasil ";
         $concatBarangSudahDiProses = $this->sqlArray($this->sqlQuery($query));
         $explodeConcatBarangProses = explode(" ",$concatBarangSudahDiProses['hasil']);
         $barangSudahDiProses = $explodeConcatBarangProses[3];
         $jumlahBarangMasuk += $jumlahBarang;
         echo "ID PENERIMAAN => $idPenerimaan | detail => ".$query." ". "Jumlah Data Masuk = $jumlahBarangMasuk " .  $nomorUrutWhile." / $jumlahPerimanaan ".$concatBarangSudahDiProses['hasil']." \n";
        }
       // $this->sqlQuery("update t_penerimaan_barang set status_posting = '1' where id = '".$dataPenerimaan['Id']."'");
        $nomorUrutWhile+=1;
      }

  }

  function stringDetector($string){
      $string = str_replace("`","",$string);
      $string = str_replace("'","",$string);
      $string = str_replace(" ","",$string);
      return $string;
  }
  function getTahun($tanggal){
    $explodeTanggal = explode("-",$tanggal);
    return $explodeTanggal[0];
  }

  function getStatusAset($fmSTATUSASET, $fmKONDISIBARANG, $fmHARGABARANG, $f,$g,$h,$i,$j,$fmTAHUN=''){
  	switch($this->VERSI_NAME){ //$fmSTATUSASET, $ArBarang[0], $fmHARGABARANG

  		case 'SERANG' : { //kab
  			if($fmSTATUSASET !=5 && $fmSTATUSASET !=6 && $fmSTATUSASET !=7  ){//pindah tangan, tgr, pemitraan, (tidak rubah aset)
  				//if($fmKONDISIBARANG==3 && ($fmSTATUSASET==3 || $fmSTATUSASET==8 || $fmSTATUSASET==9) ){ //rb otomatis
  				if($fmKONDISIBARANG==3 ){ //rb oto
  					$fmSTATUSASET=9;
  				}else{ //extra, intra , tdk oto
  					if(
  						$fmHARGABARANG< 1000000
  					){
  						$fmSTATUSASET = 10;//extra
  					//}else if( $ArBarang[0].$ArBarang[1]=='0724'  ){
  					//	$fmSTATUSASET = 8;	//tak berwujud
  					}else{
  						//$fmSTATUSASET = 3;	//intra
  						$fmSTATUSASET = $f.$g =='0724' ? 8:3;
  					}
  				}
  			}
  			break;
  		}
  		case 'GARUT' : {
  			if($fmSTATUSASET !=5 && $fmSTATUSASET !=6 && $fmSTATUSASET !=7  ){//pindah tangan, tgr, pemitraan, (tidak rubah aset)

  				if($fmKONDISIBARANG==3 ){ //rb oto
  					$fmSTATUSASET=9;
  				}else{
  					if(
  						( $fmHARGABARANG >= 250000  ) ||
  						( $f.$g =='0517'   ) || //buku
  						( $f.$g.$h.$i.$j=='02060201046' ) || //karpet
  						( $f=='01' || $f=='03' || $f=='04' || $f=='06' || $f=='07')
  					){
  						//$fmSTATUSASET = 3;
  						$fmSTATUSASET = $f.$g =='0724' ? 8:3;
  					}else{
  						$fmSTATUSASET = 10;
  					}
  				}
  			}
  			break;
  		}
  		case 'BOGOR' : {
  			if($fmSTATUSASET !=5 && $fmSTATUSASET !=6 && $fmSTATUSASET !=7 && $fmSTATUSASET!=10  ){	//pindah tangan, tgr, pemitraan, (tidak rubah aset)
  				/*if($fmKONDISIBARANG==3  ){ //RB oto aset lainnya
  					$fmSTATUSASET=9;
  				}else{
  					if ( $fmSTATUSASET == '' ){
  						$fmSTATUSASET = $f.$g =='0724' ? 8:3; //ATB
  					}
  				}*/
  				//cek intra
  				if( ($fmHARGABARANG < 100000 && $fmTAHUN<=2014 ) || ( $fmHARGABARANG <300000 && $fmTAHUN>2014 )  ){ //ekstra
  					$fmSTATUSASET=10;
  				}else if($fmKONDISIBARANG==3 ){ //aset lain
  					$fmSTATUSASET=9;
  				}else if( $f.$g =='0724'){
  					$fmSTATUSASET = 8; //ATB
  				}else{
  					$fmSTATUSASET = 3;
  				}
  			}
  			if($f == "05")$fmSTATUSASET = 3;
  			break;
  		}


  	}

  	return $fmSTATUSASET;
  }

  function QyrTmpl1Brs($tablenya, $field='*',$where = '',$eksekusi=1) {
		$qry = "SELECT $field FROM $tablenya $where";
		$hasil =array();
		if($eksekusi == 1){
			$aqry = $this->sqlQuery($qry);
			$hasil = $this->sqlArray($aqry);
		}


		return array('hasil'=>$hasil, 'cek'=>$qry);
	}

}

$wakwaw = new postingPenerimaan();







 ?>
