<?php
include 'config.php';
include 'excel_reader.php';
class getIdPenerimaan extends Config{
  function __construct(){
      $options = getopt("f:hp:");
      $namaFile = $options['f'];
      $nameFileExcel = $namaFile;
      $excel = new PhpExcelReader;
      $excel->read("$namaFile");
      $sheet = $excel->sheets[0];
         $x = 2;
         $jumlahData = $sheet['numRows'] - 1;
         while($x <= $sheet['numRows']) {
           $getDataPenerimaan = $this->sqlArray($this->sqlQuery("select * from t_penerimaan_barang where Id_penerimaan = '".$sheet['cells'][$x][1]."' "));
           $oldFile = file_get_contents("result.txt");
           file_put_contents("result.txt",$oldFile."\n".$getDataPenerimaan['Id']);
           $x++;
         }
  }

  function stringDetector($string){
      $string = str_replace("`","",$string);
      $string = str_replace("'","",$string);
      $string = str_replace(" ","",$string);
      return $string;
  }

}

$wakwaw = new getIdPenerimaan();







 ?>
